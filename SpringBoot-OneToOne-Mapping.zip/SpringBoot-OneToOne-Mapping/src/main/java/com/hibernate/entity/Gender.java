package com.hibernate.entity;

public enum Gender {
	Male,female,other;
}
