package com.practice.learncode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearncodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
