package com.practice.learncode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearncodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearncodeApplication.class, args);
	}

}
