package com.hibernate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.hibernate.entity.Address;
import com.hibernate.entity.Gender;
import com.hibernate.entity.Person;
import com.hibernate.repository.AddressRepository;
import com.hibernate.repository.PersonRepository;

@SpringBootApplication
public class SpringBootOneToOneMappingApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOneToOneMappingApplication.class, args);
	}

	@Autowired
	private PersonRepository personRepository;
	
	@Autowired	
	private AddressRepository addressRepository;
	
	
	@Override
	public void run(String... args) throws Exception {

		Address address = new Address();
		address.sethName("Baba pg");
		address.setPin("281405");
		
		Person person = new Person();
		person.setName("Badan Singh");
		person.setGender(Gender.Male);
		person.setAddress(address);
		address.setPerson(person);
		
//		addressRepository.save(address);
		personRepository.save(person);
	}

}
