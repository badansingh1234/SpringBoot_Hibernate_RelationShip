package com.practice.learncode.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class LaptopDetail {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long laptopId;
	private String laptopName;
	
	public LaptopDetail() {
		// TODO Auto-generated constructor stub
	}
	public LaptopDetail(String laptopName) {
		this.laptopName = laptopName;
	}
	public Long getLaptopId() {
		return laptopId;
	}
	public void setLaptopId(Long laptopId) {
		this.laptopId = laptopId;
	}
	public String getLaptopName() {
		return laptopName;
	}
	public void setLaptopName(String laptopName) {
		this.laptopName = laptopName;
	}
	@Override
	public String toString() {
		return "LaptopDetail [laptopId=" + laptopId + ", laptopName=" + laptopName + "]";
	}
	
}
