package com.practice.learncode.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.practice.learncode.entity.EmployeeDetail;

@Repository
public interface EmployeeDetailRepository extends JpaRepository<EmployeeDetail, Long>{
	
	public List<EmployeeDetail> findByEmpName(String name);
		
	}
