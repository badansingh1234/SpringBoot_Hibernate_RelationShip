package com.mapping;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.mapping.entity.Comment;
import com.mapping.entity.Post;
import com.mapping.repository.CommentRepository;
import com.mapping.repository.PostRepository;

@SpringBootApplication
public class SpringBootOneToManyMappingApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOneToManyMappingApplication.class, args);
	}
	
	@Autowired
	private PostRepository postRepository;
	
	@Autowired
	private CommentRepository commentRepository;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		Post post = new Post("one to many mapping","Using Hibernate and springboot");
		
		Comment comment1 = new Comment("very usefull ");
		Comment comment2 = new Comment("informative");
		Comment comment3 = new Comment("great post");
		
		post.getComments().add(comment1);
		post.getComments().add(comment2);
		post.getComments().add(comment3);
		
		this.postRepository.save(post);
	}

}
