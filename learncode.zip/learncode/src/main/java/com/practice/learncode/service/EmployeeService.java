package com.practice.learncode.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.practice.learncode.entity.EmployeeDetail;
import com.practice.learncode.repository.AddressDetailRepository;
import com.practice.learncode.repository.DepartmentRepository;
import com.practice.learncode.repository.EmployeeDetailRepository;
import com.practice.learncode.repository.LaptopDetailRepository;

@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeDetailRepository repository;
	
	// save one employee....
	public EmployeeDetail saveEmployee(EmployeeDetail employeeDetail) {
			return 	repository.save(employeeDetail);
	}
	
	// save multiple employee... 
	public Iterable<EmployeeDetail> saveAllEmployee(Iterable<EmployeeDetail> employeeDetail) {
		return repository.saveAll(employeeDetail);
	}
	
	// find all employee...
	public List<EmployeeDetail> findAllEmployee(){
		return repository.findAll();
	}
	
	// find by id employee @PathVaraible And @RequestParam
	public EmployeeDetail findOneEmp(long id) {
		 Optional<EmployeeDetail> optional= repository.findById(id);
		 EmployeeDetail employeeDetail = optional.get();
		 return employeeDetail;
	}
	
	// update one employee by id 
	public EmployeeDetail updateEmployee(EmployeeDetail employeeDetail, long id) {
		Optional<EmployeeDetail> optional= repository.findById(id);
		EmployeeDetail employeeDetail2 = optional.get();
		
		employeeDetail2.setEmpName(employeeDetail.getEmpName());
		employeeDetail2.setEmpMobileNo(employeeDetail.getEmpMobileNo());
		employeeDetail2.setEmpSalary(employeeDetail.getEmpSalary());
		employeeDetail2.setEmpDesignation(employeeDetail.getEmpDesignation());
		employeeDetail2.setLaptopDetail(employeeDetail.getLaptopDetail());
		employeeDetail2.setAddressDetail(employeeDetail.getAddressDetail());
		employeeDetail2.setEmpDepartmentDetails(employeeDetail.getEmpDepartmentDetails());
		
		return repository.save(employeeDetail2);
	}
	
	// update name of employee by using patch
	public EmployeeDetail nameEditEmployee(EmployeeDetail employeeDetail, long id) {
		Optional<EmployeeDetail> optional = repository.findById(id);
		EmployeeDetail nameEditEmployeeDetail = optional.get();
		nameEditEmployeeDetail.setEmpName(employeeDetail.getEmpName());
		return  repository.save(nameEditEmployeeDetail);
	}
	
	
	// change all attribute method
	public String allAtributeChange(EmployeeDetail employeeDetail, long id) {
		long Id = employeeDetail.getEmpId();
		EmployeeDetail newEmpDetail = repository.getById(id);
		if(newEmpDetail == null) {
			return "not found";
		}else
		{
			newEmpDetail.setEmpName(employeeDetail.getEmpName());
			newEmpDetail.setEmpSalary(employeeDetail.getEmpSalary());
			newEmpDetail.setEmpMobileNo(employeeDetail.getEmpMobileNo());
			newEmpDetail.setLaptopDetail(employeeDetail.getLaptopDetail());
			newEmpDetail.setAddressDetail(employeeDetail.getAddressDetail());
			newEmpDetail.setEmpDepartmentDetails(employeeDetail.getEmpDepartmentDetails());
			repository.save(newEmpDetail);
			return "update sucess";
		}
		
	}
	
	// delete employee by id
	public String deleteEmployeeById(long id) {
		Optional<EmployeeDetail> optional = repository.findById(id);
		if(optional.isPresent()) {
			repository.deleteById(id);
			return "Delete Employee";
		}else 
		{
			return "not found";
		}
	}
	
	// custom method by name
	
	public List<EmployeeDetail> findByName(String name) {
		
		return repository.findByEmpName(name);
	}
	
}
