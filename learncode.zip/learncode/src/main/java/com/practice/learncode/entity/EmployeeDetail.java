package com.practice.learncode.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="employee_detail")
public class EmployeeDetail {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long empId;
	private String empName;
	private String empMobileNo;
	private String empSalary;
	private String empDesignation;
	
	// employee to laptop_detail onetoone mapping
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "lap_id")
	private LaptopDetail laptopDetail;
	
	// employee to multi address onetomany
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="empId")
	private List<AddressDetail> addressDetail;
	
	// employee to hold mulitple department
	@ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JoinTable(
			name="emp_dep_many2many",
			joinColumns = @JoinColumn(name="employee_id",referencedColumnName = "empId"),
			inverseJoinColumns = @JoinColumn(name="department_id", referencedColumnName = "deptId")
			)
	private Set<DepartmentDetail> empDepartmentDetails;
	
	public EmployeeDetail(){ }
	public EmployeeDetail(Long empId, String empName, String empMobileNo, String empSalary, String empDesignation,
			LaptopDetail laptopDetail, List<AddressDetail> addressDetail, Set<DepartmentDetail> empDepartmentDetails) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empMobileNo = empMobileNo;
		this.empSalary = empSalary;
		this.empDesignation = empDesignation;
		this.laptopDetail = laptopDetail;
		this.addressDetail = addressDetail;
		this.empDepartmentDetails = empDepartmentDetails;
	}
	public Long getEmpId() {
		return empId;
	}
	public void setEmpId(Long empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpMobileNo() {
		return empMobileNo;
	}
	public void setEmpMobileNo(String empMobileNo) {
		this.empMobileNo = empMobileNo;
	}
	public String getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(String empSalary) {
		this.empSalary = empSalary;
	}
	public String getEmpDesignation() {
		return empDesignation;
	}
	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}
	public LaptopDetail getLaptopDetail() {
		return laptopDetail;
	}
	public void setLaptopDetail(LaptopDetail laptopDetail) {
		this.laptopDetail = laptopDetail;
	}
	public List<AddressDetail> getAddressDetail() {
		return addressDetail;
	}
	public void setAddressDetail(List<AddressDetail> addressDetail) {
		this.addressDetail = addressDetail;
	}
	
	public Set<DepartmentDetail> getEmpDepartmentDetails() {
		return empDepartmentDetails;
	}
	public void setEmpDepartmentDetails(Set<DepartmentDetail> empDepartmentDetails) {
		this.empDepartmentDetails = empDepartmentDetails;
	}
	@Override
	public String toString() {
		return "EmployeeDetail [empId=" + empId + ", empName=" + empName + ", empMobileNo=" + empMobileNo
				+ ", empSalary=" + empSalary + ", empDesignation=" + empDesignation + ", laptopDetail=" + laptopDetail
				+ ", addressDetail=" + addressDetail + "]";
	}
}
