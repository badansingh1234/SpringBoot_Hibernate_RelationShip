package com.practice.learncode.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.practice.learncode.entity.AddressDetail;

@Repository
public interface AddressDetailRepository extends JpaRepository<AddressDetail, Long> {

}
