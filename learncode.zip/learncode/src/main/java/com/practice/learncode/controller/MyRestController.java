package com.practice.learncode.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.practice.learncode.entity.EmployeeDetail;
import com.practice.learncode.service.EmployeeService;

@RestController
public class MyRestController {

	@Autowired
	private EmployeeService empService;
	
	 // save for one employee controller
	@RequestMapping("/employee")  
	public EmployeeDetail  createEmployee(@RequestBody EmployeeDetail employeeDetail) {
		 return  empService.saveEmployee(employeeDetail);
	}
	
	// save Multiple employee controller
	@RequestMapping("/employees")   
	public Iterable<EmployeeDetail> createMultipleEmployee(@RequestBody Iterable<EmployeeDetail> empIterable) {
		return empService.saveAllEmployee(empIterable);
	}
	
	 // find all employee controller
	@RequestMapping("/findAll")   
	public List<EmployeeDetail> searchAllEmplyoee(){
		return empService.findAllEmployee();
	}
	
	 // find by id employee controller using @PathVariable
	@RequestMapping(value = "/find/{id}",method = RequestMethod.GET)  
	public EmployeeDetail findOneEmpById(@PathVariable long id) {
		return empService.findOneEmp(id);
	}
	
	  // find by id employee controller using @RequestParam
	@RequestMapping("/getOne")  
	public EmployeeDetail getOneEmployee(@RequestParam long id) {
		return empService.findOneEmp(id);
	}
	
	 // edit / update by id controller 
	@RequestMapping(value="/edit/{id}",method=RequestMethod.PUT)   
	public EmployeeDetail editEmployee(@RequestBody EmployeeDetail employeeDetail,@PathVariable long id) {
		return empService.updateEmployee(employeeDetail, id);
	}
	
	 // patch method update by name controller 
	@RequestMapping(value="/update/{id}",method=RequestMethod.PATCH)   
	public EmployeeDetail updateEmployeeByName(@RequestBody EmployeeDetail employeeDetail, @PathVariable("id") long id) {
		return	empService.nameEditEmployee(employeeDetail, id);
	}
	
	// all attribute change in employee 
	@RequestMapping(value="/allAtribute/{id}", method=RequestMethod.PUT)
	public String allAttributeEmployee(@RequestBody EmployeeDetail employeeDetail,@PathVariable long id ) {
		return empService.allAtributeChange(employeeDetail, id);
	}
	
	// delete one employee by id using path variable
	@RequestMapping("/delete/{id}")  
	public String deleteOneEmployee(@PathVariable long id) {
		return empService.deleteEmployeeById(id);
	}
	
	// delete one employee by id using Request param
	@RequestMapping(value="/delet", method=RequestMethod.DELETE)
	public String deleteOneEmp(@RequestParam long id ) {
		return empService.deleteEmployeeById(id);
	}
	
	// custom method find by name and using @requestparam
	@RequestMapping(value = "emp", method = RequestMethod.GET)
	public List<EmployeeDetail> findByName(@RequestParam String name){
		return empService.findByName(name);
	}
	
	// custom method find by name using @pathvariable
	
	@RequestMapping(value = "employee/{name}",method = RequestMethod.GET)
	public List<EmployeeDetail> findByName1(@PathVariable("name") String name){
		return empService.findByName(name);
	}
	
}
