package com.practice.learncode.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class DepartmentDetail {
	
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	private long deptId;
	private String deptName;
	
	@ManyToMany(cascade = CascadeType.ALL,mappedBy = "empDepartmentDetails",fetch = FetchType.EAGER)
	private Set<EmployeeDetail> employeeDetails;
	
	public DepartmentDetail() {}
	public DepartmentDetail(String deptName, Set<EmployeeDetail> employeeDetails) {
		this.deptName = deptName;
		this.employeeDetails = employeeDetails;
	}

	public long getDeptId() {
		return deptId;
	}

	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	public Set<EmployeeDetail> getEmployeeDetails() {
		return employeeDetails;
	}
	public void setEmployeeDetails(Set<EmployeeDetail> employeeDetails) {
		this.employeeDetails = employeeDetails;
	}
	@Override
	public String toString() {
		return "DepartmentDetail [deptId=" + deptId + ", deptName=" + deptName ;
	}
	
	
}
